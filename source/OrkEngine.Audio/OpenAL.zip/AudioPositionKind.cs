﻿namespace OrkEngine3D.Audio
{
    public enum AudioPositionKind
    {
        AbsoluteWorld,
        ListenerRelative
    }
}