﻿using System;
using OpenTK.Audio.OpenAL;

namespace OrkEngine3D.Audio.OpenAL
{
    public class OpenALAudioSource : AudioSource
    {
        public int ID { get; }

        public OpenALAudioSource()
        {
            ID = AL.GenSource();
            if (ID == 0)
            {
                throw new InvalidOperationException("Too many OpenALAudioSources.");
            }
        }

        public override float Gain
        {
            get
            {
                AL.GetSource(ID, ALSourcef.Gain, out float gain);
                return gain;
            }
            set
            {
                AL.Source(ID, ALSourcef.Gain, value);
            }
        }

        public override float Pitch 
        { 
            get
            {
                AL.GetSource(ID, ALSourcef.Pitch, out float pitch);
                return pitch;
            }
            set
            {
                if (value < 0.5 || value > 2.0f)
                {
                    throw new ArgumentOutOfRangeException("Pitch must be between 0.5 and 2.0");
                }

                AL.Source(ID, ALSourcef.Pitch, value);
            }
        }

        public override bool Looping
        {
            get
            {
                AL.GenSource(ID, ALSourceb.Looping, out int looping)
            }
            set;
        }
    }
}
