﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrkEngine3D.Audio
{
    public abstract class AudioResourceFactory
    {
        public abstract AudioSource CreateAudioSource();
        public abstract AudioBuffer CreateAudioBuffer();
    }
}
