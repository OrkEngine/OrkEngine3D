﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrkEngine3D.Audio
{
    public enum BufferAudioFormat
    {
        Mono8,
        Mono16,
        Stereo8,
        Stereo16
    }
}
