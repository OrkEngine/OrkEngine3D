﻿namespace OrkEngine3D.Audio
{
    public abstract class AudioBuffer : IDisposable
    {
        [Obsolete("Broken Code", true)]
        public abstract void BufferData<T>(T[] buffer, BufferAudioFormat format, int sizeInBytes, int frequency) where T : struct;
        public abstract void BufferData<T>(IntPtr buffer, BufferAudioFormat format, int sizeInBytes, int frequency) where T : struct;
        public abstract void Dispose();
    }
}
